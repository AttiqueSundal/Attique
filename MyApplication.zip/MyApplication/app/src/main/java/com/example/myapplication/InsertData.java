package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InsertData extends AppCompatActivity {

    EditText t1, t2,t3;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate (Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.abc);

            t1=  (EditText) findViewById(R.id.t1);
            t2 = (EditText) findViewById(R.id.t2);
            t2 = (EditText) findViewById(R.id.t3);

    }

    public void addRecord (View view) {
try {


    DataHelper db = new DataHelper(this);

    String res = db.addRecord(t1.getText().toString(), t2.getText().toString(), t3.getText().toString());


    Toast.makeText(this, res, Toast.LENGTH_SHORT).show();

    t1.setText("");
    t2.setText("");
    t3.setText("");
}
catch (Exception e) {
    // This will catch any exception, because they are all descended from Exception
    System.out.println("Error " + e.getMessage());
    return;
}

        }
    }




